package cn.itcast.service;

import java.util.List;

import cn.itcast.domain.Upfile;

public interface BusinessService {

	void addUpfile(Upfile upfile);

	List getAllUpfile();

	Upfile findUpfile(String id);

}