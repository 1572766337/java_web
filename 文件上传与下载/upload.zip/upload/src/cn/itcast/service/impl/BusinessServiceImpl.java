package cn.itcast.service.impl;

import java.util.List;

import cn.itcast.dao.UpfileDao;
import cn.itcast.domain.Upfile;
import cn.itcast.factory.DaoFactory;
import cn.itcast.service.BusinessService;

public class BusinessServiceImpl implements BusinessService {

	private UpfileDao dao = DaoFactory.getInstance().createDao(UpfileDao.class);
	
	public void addUpfile(Upfile upfile){
		dao.add(upfile);
	}
	
	public List getAllUpfile(){
		return dao.getAll();
	}
	
	public Upfile findUpfile(String id){
		return dao.find(id);
	}
	
	public void delete(String id){
		
		
		
	}
	
}
